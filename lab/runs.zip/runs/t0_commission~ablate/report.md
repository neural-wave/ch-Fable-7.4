# t0_commission~ablate

Grain: NRPREM {'policy_id': 'PR_POLNR', 'due_nr': 'PR_DUENR'} (reverse coverage 94.8%; others: NREVNT 34.9%, NRBOOK 4.5%)
Filter: PR_STATE in ['P'] (excluded rows {'R': 5816, 'O': 3614, 'W': 3056}, errors 0)

## amount

Relation: value / PR_AMTRC: 6 clusters, noise 10, ambiguous 0
| center | rows | roundings that reproduce all rows |
|---|---|---|
| 0.005 | 137 | HALF_UP UP CEILING |
| 0.01 | 253 | HALF_UP HALF_EVEN HALF_DOWN DOWN UP FLOOR CEILING |
| 0.015 | 185 | HALF_UP HALF_EVEN HALF_DOWN DOWN UP FLOOR CEILING |
| 0.02 | 53683 | HALF_UP HALF_EVEN HALF_DOWN DOWN UP FLOOR CEILING |
| 0.03 | 102865 | HALF_UP HALF_EVEN HALF_DOWN DOWN UP FLOOR CEILING |
| 0.04 | 68725 | HALF_UP HALF_EVEN HALF_DOWN DOWN UP FLOOR CEILING |
Other relation: value / PR_AMTDU: 18 clusters, 223728 rows exact, noise 2130
Other relation: value / PH_PREMI@PR_DUEDT: 18 clusters, 223728 rows exact, noise 2130
Optimal trees: errors 1430, leaves 6; smallest feature sets: {BR_TIER, PH_PRDCD}; {BR_TIER, PH_FREQ}; {BR_TIER, RK_TARKEY[6]}
  BR_TIER is interchangeable with: EC_RATE
  PH_PRDCD is interchangeable with: PD_INIMON, PD_SRPSCL, PD_TARFAM, PH_PRDCD[3], PH_PRDCD[4], RK_TARKEY[2], RK_TARKEY[6]
  conflicting vectors (same features, different clusters): 7
  conflicting vector (BR_TIER = B, PH_PRDCD = FLKL): clusters 0.03 x 60987, 0.02 x 201, 0.04 x 164; example ['BL10000309', 1]
  conflicting vector (BR_TIER = A, PH_PRDCD = FLKL): clusters 0.04 x 43452, 0.03 x 115, 0.02 x 2; example ['BL10002227', 1]
  conflicting vector (BR_TIER = B, PH_PRDCD = FLFX): clusters 0.03 x 41618, 0.02 x 314; example ['BL10001976', 2]
  conflicting vector (BR_TIER = C, PH_PRDCD = FLKL): clusters 0.02 x 33013, 0.04 x 354, 0.03 x 68; example ['BL10000058', 1]
  conflicting vector (BR_TIER = A, PH_PRDCD = FLFX): clusters 0.04 x 24685, 0.02 x 64, 0.03 x 5; example ['BL10000968', 1]
CART for comparison: 8 leaves on BR_REGIO, BR_TIER, PH_PRDCD, RK_TARKEY[6], RK_UWCLS
Best candidate C2.1: 6 constants on BR_TIER, PH_PRDCD, ROUND_HALF_UP; total 224418/225858, holdout 43880/44052
Same train rows (the data cannot tell them apart): C2.2, C2.3, C2.1/UP, C2.2/UP, C2.3/UP, C2.1/CEILING
  C2.1/HALF_EVEN: 6 constants on BR_TIER, PH_PRDCD, ROUND_HALF_EVEN: total 224417
  C2.2/HALF_EVEN: 6 constants on BR_TIER, PH_FREQ, ROUND_HALF_EVEN: total 224417
  C2.3/HALF_EVEN: 6 constants on BR_TIER, RK_TARKEY[6], ROUND_HALF_EVEN: total 224417
  C1/HALF_EVEN: 8 constants on BR_REGIO, BR_TIER, PH_PRDCD, RK_TARKEY[6], RK_UWCLS, ROUND_HALF_EVEN: total 224417
  card L1: BR_TIER = A and PH_PRDCD = FLSP -> 0.015 (184 rows, e.g. [['BL10000007', 1]])
  card L2: BR_TIER = A and PH_PRDCD != FLSP -> 0.04 (68323 rows, e.g. [['BL10000003', 1]])
  card L3: BR_TIER != A and BR_TIER = B and PH_PRDCD = FLSP -> 0.01 (254 rows, e.g. [['BL10000012', 1]])
  card L4: BR_TIER != A and BR_TIER = B and PH_PRDCD != FLSP -> 0.03 (103284 rows, e.g. [['BL10000013', 1]])
  card L5: BR_TIER != A and BR_TIER != B and PH_PRDCD = FLSP -> 0.005 (137 rows, e.g. [['BL10000034', 1]])
  card L6: BR_TIER != A and BR_TIER != B and PH_PRDCD != FLSP -> 0.02 (53666 rows, e.g. [['BL10000001', 2]])
Residuals: 1440 rows. Fit another cluster (a condition is missing): 0.03 -> 0.02 x 515, 0.02 -> 0.04 x 424, 0.03 -> 0.04 x 164, 0.02 -> 0.03 x 140, 0.04 -> 0.03 x 120, 0.04 -> 0.02 x 66. Noise 10 (whole-unit deltas 10, listed in NREXCP 6), ambiguous 0
  ['BL10000237', 41] noise: target 49.40, computed 5.40, delta 44.00
  ['BL10001299', 103] noise: target 79.70, computed 5.70, delta 74.00
  ['BL10001328', 1] noise: target 936.00, computed 859.00, delta 77.00
  ['BL10001567', 6] noise: target 28.50, computed 1.50, delta 27.00
  ['BL10002438', 11] noise: target 310.40, computed 242.40, delta 68.00
  ['BL10002462', 5] noise: target 101.80, computed 85.80, delta 16.00
  ['BL10003175', 247] noise: target 20.70, computed 11.70, delta 9.00
  ['BL10004049', 6] noise: target 75.15, computed 39.15, delta 36.00
